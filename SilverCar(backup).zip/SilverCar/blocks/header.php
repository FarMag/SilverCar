<header>
        <!-- <php
            // Проверяем, авторизован ли пользователь
            $isLoggedIn = false;  // здесь должен быть код для проверки авторизации

            if ($isLoggedIn) {
                echo '<a href="logout.php" class="login-button">Выйти</a>';
            } else {
                echo '<a href="login.php" class="login-button">Войти</a>';
                echo '<a href="login.php" class="regist-button">Регистрация</a>';
            }
        ?> -->

        <?php 
            $current_file = basename($_SERVER['PHP_SELF']);
            if (!empty($_SESSION["user"])){
                
                if($current_file != 'account.php'){
                    echo '<a href="/account.php" class="account-button";>Кабинет пользователя</a>';
                }
            }
            elseif ($current_file != 'login.php' && $current_file != 'registration.php'){
                echo '<a href="/registration.php" class="regist-button">Регистрация</a>
                <a href="/login.php" class="login-button">Войти</a>';
            }
            // else{
            //     echo '<a href="/login.php" class="login-button">Особый логин</a>';
            // }


           
            

        

        if ($current_file == 'main_window.php') {
            
            echo'<a href="#top" class="Top-Logo2">SilverCar</a>';
        }elseif($current_file == 'car_window.php' || $current_file == 'admin_add_car.php' || $current_file == 'admin_panel.php' || $current_file == 'request.php'){
            echo'<a href="/main_window.php" class="Top-Logo2">SilverCar</a>';
        }elseif($current_file == 'account.php'){
            echo'<a href="/main_window.php" class="Top-Logo3">SilverCar</a>';
        }else{
            
            echo'<a href="/main_window.php" class="Top-Logo1">SilverCar</a>';
        }
        
        ?>
    <h2>Салон поддержанных автомобилей</h2>
</header>