<footer class="footer">
    <p>Телефон: 8(800)555-35-35&emsp;|&emsp;Адрес: г. Москва, ул. Смольная 49&emsp;|&emsp;Email: silver_gosling@mail.ru</p>
    
    <p class="copyright">
      © 2023 Все права защищены. SilverCar
    </p>
</footer>