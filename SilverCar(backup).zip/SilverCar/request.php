<?php 
session_start();

    if (empty($_SESSION['user'])){
        header('Location: login.php');
    }
    $host = 'localhost';
    $username = 'root'; 
    $password = '';  
    $dbname = 'SilverCarDB';
    
    $conn = mysqli_connect($host, $username, $password, $dbname);
    
    if (!$conn) {
        die('Ошибка соединения с MySQL: ' . mysqli_connect_error());
    }   
    
    $query = "SELECT ci.Brand, ci.Model, ci.Configuration, ci.Price, User_Name, r.User_Email FROM Request r JOIN CarInfo ci ON r.Car_ID = ci.ID";
    $result = mysqli_query($conn, $query);
    echo "<table align='center' class='table'><tr><th colspan='6'>Запросы на обратную связь</th></tr><tr><td>Марка</td><td>Модель</td><td>Цена</td><td>Комплектация</td><td>Имя пользователя</td><td>Почта пользователя</td><tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        $brand = $row['Brand'];
        $model = $row['Model'];
        $price = $row['Price'];
        $conf = $row['Configuration'];
        $name = $row['User_Name'];
        $email = $row['User_Email'];
        echo "<tr><td>$brand</td><td>$model</td><td>".number_format($price, 0, '.', ' ')." руб</td><td>$conf</td><td>$name</td><td>$email</td><tr>";
    
    };
    echo "</table>";
?>

<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.w3.org/1999/xhtml">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/header_style.css">
    <link rel="stylesheet" type="text/css" href="css/footer_style.css">
    <link rel="stylesheet" type="text/css" href="css/request.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

</head>
<?php require "blocks/header.php" ?>



<?php require "blocks/footer.php" ?>

</html>