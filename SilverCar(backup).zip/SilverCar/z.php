<?php 
session_start();
if(isset($_POST["sort_select"])){
    $sort = $_POST["sort_select"];
}

$brand_arr = ["Porsche", "Mercedes-Benz", "BMW", "Volkswagen", "Rolls-Royce", "Lexus", "Toyota", "Zeekr",
"ВАЗ (LADA)", "Dodge", "Mitsubishi", "LiXiang", "Genesis", "Jeep", "Land Rover"];



$aBrand = $_POST['cd_brand'];
  if(empty($aBrand)) 
  {
    echo("Вы не выбрали ни одну марку.");
  } 
  else
  {
    $N = count($aBrand);

    echo("Вы выбрали $N марок(й): ");
    for($i=0; $i < $N; $i++)
    {
      echo($aBrand[$i] . " ");
    }
  }
?>



<html>
    <head>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Zen+Dots&display=swap');

/* .Top-Logo {
    font-family: 'Zen Dots', sans-serif;
    color: #FFCF40;
    font-size: 60px;
    font-weight: bold;
    padding: 10px auto;
    padding-left: 260px;
    margin: 0;
}
h2 {
    color: #FFFFFF;
    font-family: 'Roboto', sans-serif;
    font-size: 20px;
    font-weight: normal;
    padding: 10px auto;
    padding-bottom: 0;
    margin: 0;
  } */
/* #pageContent {
    height: calc(20vh - 10px);
    overflow-y: auto;
} */

html{
    scroll-behavior: smooth;
    height: 100%}

body {
     font-family: Arial, sans-serif;
     background-color: #FFFFFF;
     margin: 0;
     padding: 0;
     margin-top: 150px;
     height: 100%;
     overflow-x: hidden;
}
.container {
    width: 29%;
    margin-top: 40px;
    margin-left: 50px;
    Display:inline-block;
}
.car {
    
    left: 150px; 
    background-color: #000000;
     border:#ffcf40 solid 1px;
     padding: 20px;
     height: 380px;
     margin-bottom: 20px;
     border-radius: 5px;
     box-shadow: 0 0 10px rgba(0,0,0,0.1);
     border-radius: 20px;
     cursor: pointer;
     display: flex;
}
.car h2 {
    color: #ffffff;
    font-family: 'Roboto', sans-serif;
    font-size: 30px;
    font-weight: bold;
    padding: 10px auto;
    padding-bottom: 0;
    margin: 5px;
     /* font-size: 15px;
     margin: 0; */
}
.car table{
    font-family: 'Roboto', sans-serif;
    font-size: 28px;
    font-weight: normal;
    padding-top: 0;
    padding-bottom: 0;
    margin: 3px;
}
.car .info_table {
    color: #ffffff;
    font-family: 'Roboto', sans-serif;
    font-size: 24px;
    font-weight: bold;
    padding: 10px auto;
    padding-bottom: 0;
    margin: 5px;
}
.car img{
    width: 100%;
    border-radius: 10px;
}
.car h3 {
    color: #FFCF40;
    font-family: 'Roboto', sans-serif;
    font-size: 35px;
    font-weight: bold;
    padding: 10px auto;
    padding-bottom: 0;
    margin: 5px;
    -webkit-text-stroke: 0px black;
}

h4{
    font-family: "Roboto", sans-serif;
    font-size: 26px;
    text-align: center;
    margin-top: 20px;
    margin-bottom: 10px;
}

label{
    font-family: 'Roboto', sans-serif;
    font-size: 20px;
}

/* .login-button {
    text-decoration: none;
    float: right;
    margin-right: 40px;
    margin-top: 15px;
    background-color: #FFCF40;
    color: #333333;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    transition: 0.5s;
    cursor: pointer;
    opacity: 1;
}
.login-button:hover {
    background-color: #ffe390;
}
.regist-button {
    text-decoration: none;
    float: right;
    margin-right: 20px;
    margin-top: 15px;
    background-color: #FFCF40;
    color: #333333;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.5s;
    opacity: 1;
}
.regist-button:hover {
    background-color: #ffe390;
} */
/* button {
    background-color: #FFCF40;
    color: #FFFFFF;
    font-size: 26px;
    font-weight: bold;
    padding: 14px;
    margin: 3px;
    border: none;
    cursor: pointer;
    border-radius: 20px;
    transition: 0.5s;
    text-align: center;
}
button:hover {
    background-color: #ffe390;
} */

/* .car .btn-modal-conn{
    background:#ff9500;
    border:#e08403 solid 1px;
    border-radius:3px;
    color:#fff;
    display:inline-block;
    padding:8px 15px;
    text-decoration:none;
    text-align:center;
    min-width:60px;
    position:relative;
    transition:color .1s ease}
.btn-modal-conn:hover{background:#e08403} */

.selectWrapper{
    border-radius:10px;
    display:inline-block;
    overflow:hidden;
    background:#cccccc;
    border:1px solid #cccccc;
    position: relative;
    margin-left: 50px;
  }
  .selectBox{
    width:280px;
    height:30px;
    border:0px;
    outline:none;
    background-color: #FFFFFF;
    font-size: 18px;
    font-family: "Roboto", sans-serif;
    position: relative;
    display: block;

  }







  button[type="submit"] {
    background-color: #ffcf40;
    color: white;
  }
  
  .btn {
    background:#FFFFFF;
    border-radius:3px;
    color:#000000;
    font-size: 18px;
    font-family: "Roboto", sans-serif;
    float: right;
    border-radius: 10px;
    Width: 100px;
    height: 32px;
    cursor: pointer;
    transition: 0.5s;
    display:block;
    margin-right: 40px;
}
.btn:hover {
    background-color: #ffe390;
}

.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    overflow-y: hidden;
  }
  
  .modal-content {
    background-color: #fff;
    margin: 15px;
    margin-top: 120px;
    padding: 20px;
    border: 1px solid #888;
    width: 250px;
    height: 520px;
    border-radius: 10px;
    float: right;
  }
  
  .close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
  }
  
  form {
    margin-top: 20px;
  }

.filter_btn{
    background-color: #FFCF40;
    color: #FFFFFF;
    font-size: 20px;
    font-weight: bold;
    padding: 14px;
    margin: 3px;
    border: none;
    cursor: pointer;
    border-radius: 10px;
    transition: 0.5s;
    text-align: center;
    width: 100%;
}
            </style>
</head>
<form method="POST">
 <div class="selectWrapper">
  <select name="sort_select" class="selectBox" onchange="this.form.submit()">
  <option name="by_id" value="ORDER BY ID" <?php if ($sort === 'ORDER BY ID') echo 'selected'; ?> >Сначала старые предложения</option>
  <option name="by_id_desc" value="ORDER BY ID DESC" <?php if ($sort === 'ORDER BY ID DESC') echo 'selected'; ?> >Сначала новые предложения</option>
  <option name="by_price" value="ORDER BY Price" <?php if ($sort === 'ORDER BY Price') echo 'selected'; ?> >Сначала дешевле</option>
  <option name="by_price_desc" value="ORDER BY Price DESC" <?php if ($sort === 'ORDER BY Price DESC') echo 'selected'; ?> >Сначала дороже</option>
</select>
<noscript><input type="submit" value="Submit"></noscript>
</div>

<button class="btn" type="button" id="open-modal-btn">Фильтры</button>

</form> 

<div id="modal" class="modal">
                <div class="modal-content">
                <span class="close">&times;</span><br>
                <h4>Выберите марку</h4>
                <form action="z.php" method="POST">

                <?php 
                for($i=1; $i<count($brand_arr)+1; $i++){
                    echo "<input type='checkbox' name='cb_brand[]' value=".$brand_arr[$i-1]." id='checkbox$i'>
                    <label for='checkbox$i'>".$brand_arr[$i-1]."</label>
                    <br>";
                }
                ?>
                    <br><button type="submit" class="filter_btn">Применить</button>
                </form>
                </div>
            </div>
<html>





<!-- <php
  $aBrand = $_POST['cd_brand'];
  if(empty($aBrand)) 
  {
    echo("Вы не выбрали ни одну марку.");
  } 
  else
  {
    $N = count($aBrand);

    echo("Вы выбрали $N марок(й): ");
    for($i=0; $i < $N; $i++)
    {
      echo($aBrand[$i] . " ");
    }
  }
?> -->






















<script>
    
    window.onload = function() {
  var modal = document.getElementById("modal");
  var openModalBtn = document.getElementById("open-modal-btn");
  var closeModalBtn = document.getElementsByClassName("close")[0];

  openModalBtn.onclick = function() {
    modal.style.display = "block";
  }

  closeModalBtn.onclick = function() {
    modal.style.display = "none";
  }

  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
};
</script>