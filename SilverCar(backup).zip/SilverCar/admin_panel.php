
<!-- Проверка нажата ли кнопка "Сохранить" -->
<?php
  session_start();
  
  if($_SESSION['user']['role'] != 1){
    header('Location: main_window.php');
  }

  if(isset($_POST['save']) && !empty($_POST['ID']) && !empty($_POST['Brand']) && !empty($_POST['Model']) && !empty($_POST['Price']) && !empty($_POST['Year']) 
                          && !empty($_POST['Mileage']) && !empty($_POST['Volume']) && !empty($_POST['Power']) && !empty($_POST['Engine_Type']) 
                          && !empty($_POST['Transmission']) && !empty($_POST['Configuration']) ){
    
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = ''; 
    $db_name = 'SilverCarDB';

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$conn) {
      die('Ошибка подключения к базе данных:' . mysqli_connect_error());
    }
    // else{
    //   echo "Есть подключение к БД <br />";
    // }

    $id = $_POST['ID'];
    $ID = $_POST['ID'];
    $Brand = $_POST['Brand'];
    $Model = $_POST['Model'];
    $Price = $_POST['Price'];
    $Year = $_POST['Year'];
    $Mileage = $_POST['Mileage'];
    $Volume = $_POST['Volume'];
    $Power = $_POST['Power'];
    $Engine_Type = $_POST['Engine_Type'];
    $Transmission = $_POST['Transmission'];
    $Configuration = $_POST['Configuration'];

    $query = "UPDATE CarInfo SET ID = $ID, Brand = '$Brand', Model = '$Model', Price = $Price, Year = $Year, 
    Mileage = $Mileage, Volume = $Volume, Power = $Power, Engine_Type = '$Engine_Type', 
    Transmission = '$Transmission', Configuration = '$Configuration' WHERE ID = $ID";

    if ($conn->query($query)){
      echo "Данные успешно обновлены в таблице CarInfo <br />";
    }
    else {
      echo "Ошибка, данные не обновлены в таблице CarInfo <br />";
    }


    $Pic1_1 = $_POST['Pic1'];
    $Pic1 = str_replace("\\", "\\\\", $Pic1_1);

    $Pic2_1 = $_POST['Pic2'];
    $Pic2 = str_replace("\\", "\\\\", $Pic2_1);

    $Pic3_1 = $_POST['Pic3'];
    $Pic3 = str_replace("\\", "\\\\", $Pic3_1);

    $Pic4_1 = $_POST['Pic4'];
    $Pic4 = str_replace("\\", "\\\\", $Pic4_1);

    $Pic5_1 = $_POST['Pic5'];
    $Pic5 = str_replace("\\", "\\\\", $Pic5_1);

    /*$Pic1 = $_POST['Pic1'];
    $Pic2 = $_POST['Pic2'];
    $Pic3 = $_POST['Pic3'];
    $Pic4 = $_POST['Pic4'];
    $Pic5 = $_POST['Pic5'];*/
    $query = "UPDATE CarPictures SET CarID = $ID, Pic1 = '$Pic1', 
    Pic2 = '$Pic2', Pic3 = '$Pic3', Pic4 = '$Pic4', Pic5 = '$Pic5' WHERE CarID = $ID";

    if ($conn->query($query)){
      echo "Данные успешно обновлены в таблице CarPictures <br />";
    }
    else {
      echo "Ошибка, данные не обновлены в таблице CarPictures <br />";
    }

    $conn->close(); 
    }
    else if (isset($_POST['save'])){
      echo "Ошибка, вы ввели не все данные";
    }
?>









<!-- Проверка нажата ли кнопка "Найти автомобиль" -->
<?php 
  if (isset($_POST['find_car']) && !empty($_POST['ID'])){
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = ''; 
    $db_name = 'SilverCarDB';

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$conn) {
      die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
    }
    // else{
    //   echo "Есть подключение к БД <br />";
    // }

    $post_id = $_POST["ID"];
    $query = "SELECT * FROM CarInfo ci JOIN CarPictures cp ON ci.ID = cp.carID WHERE ci.ID = $post_id";

    $result = $conn->query($query);
    if ($result->num_rows > 0){
      while ($row = mysqli_fetch_assoc($result)) {
        $id = $_POST['ID'];           
        $brand = $row['Brand'];
        $model = $row['Model'];
        $price = $row['Price'];
        $year = $row['Year'];
        $mileage = $row['Mileage'];
        $volume = $row['Volume'];
        $power = $row['Power'];
        $engine_type = $row['Engine_Type'];
        $transmission = $row['Transmission'];
        $configuration = $row['Configuration'];
        $pic1 = $row['Pic1'];
        $pic2 = $row['Pic2'];
        $pic3 = $row['Pic3'];
        $pic4 = $row['Pic4'];
        $pic5 = $row['Pic5'];
      }
      echo "Автомобиль найден <br />";
    }
    else{
      echo "Автомобиль не найден";
    }
    $conn->close();  
  }
?>






<!-- Проверка нажата ли кнопка "Удалить автомобиль" -->
<?php
  if (isset($_POST['delete_car'])){
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = ''; 
    $db_name = 'SilverCarDB';

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$conn) {
      die('Ошибка подключения к базе данных: ' . mysqli_connect_error());
    }
    // else{
    //   echo "Есть подключение к БД <br />";
    // }

    $post_id = $_POST["ID"];
    $query = "DELETE FROM CarInfo WHERE ID = $post_id";

    if ($conn->query($query)){
      echo "Данные успешно удалены <br />";
    }
    else {
      echo "Ошибка, данные не удалены <br />";
    }
    $conn->close(); 
  }
?>






<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/header_style.css">
    <link rel="stylesheet" type="text/css" href="css/footer_style.css">
    <link rel="stylesheet" type="text/css" href="css/admin_panel_style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <title>Панель администратора</title>
</head>
<?php require "blocks/header.php" ?>

<body>
  <!-- <h1>Панель администратора</h1> -->
<div class="container">
  <form method="POST" action="">
    <input type="hidden" name="ID" value="<?php if ($id != null) echo $id; ?>">
    <table class="table">
    <tr><th colspan="4">Панель администратора</th></tr> 
    <tr>
        <td>ID:</td>
        <td><input type="text" name="ID" id="ID" value="<?php if (!empty($id)) echo $id; else echo 'ID не найден' ?>"></td>
        <td>Тип двигателя:</td>
        <td><input type="text" name="Engine_Type" value="<?php if (!empty($engine_type)) echo $engine_type; elseif(!empty($Engine_Type)) echo $Engine_Type; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Марка:</td>
        <td><input type="text" name="Brand" value="<?php if (!empty($brand)) echo $brand; elseif(!empty($Brand)) echo $Brand; else echo '' ?>"></td>
        <td>Коробка передач:</td>
        <td><input type="text" name="Transmission" value="<?php if (!empty($transmission)) echo $transmission; elseif(!empty($Transmission)) echo $Transmission; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Модель:</td>
        <td><input type="text" name="Model" value="<?php if (!empty($model)) echo $model; elseif(!empty($Model)) echo $Model; else echo '' ?>"></td>
        <td>Комплектация:</td>
        <td><input type="text" name="Configuration" value="<?php if (!empty($configuration)) echo $configuration; elseif(!empty($Configuration)) echo $Configuration; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Цена:</td>
        <td><input type="text" name="Price" value="<?php if (!empty($price)) echo $price; elseif(!empty($Price)) echo $Price; else echo '' ?>"></td>
        <td>Изображение 1:</td>
        <td><input type="text" name="Pic1" value="<?php if (!empty($pic1)) echo $pic1; elseif(!empty($Pic1)) echo $Pic1; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Год:</td>
        <td><input type="text" name="Year" value="<?php if (!empty($year)) echo $year; elseif(!empty($Year)) echo $Year; else echo '' ?>"></td>
        <td>Изображение 2:</td>
        <td><input type="text" name="Pic2" value="<?php if (!empty($pic2)) echo $pic2; elseif(!empty($Pic2)) echo $Pic2; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Пробег:</td>
        <td><input type="text" name="Mileage" value="<?php if (!empty($mileage)) echo $mileage; elseif(!empty($Mileage)) echo $Mileage; else echo '' ?>"></td>
        <td>Изображение 3:</td>
        <td><input type="text" name="Pic3" value="<?php if (!empty($pic3)) echo $pic3; elseif(!empty($Pic3)) echo $Pic3; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Объем двигателя:</td>
        <td><input type="text" name="Volume" value="<?php if (!empty($volume)) echo $volume; elseif(!empty($Volume)) echo $Volume; else echo '' ?>"></td>
        <td>Изображение 4:</td>
        <td><input type="text" name="Pic4" value="<?php if (!empty($pic4)) echo $pic4; elseif(!empty($Pic4)) echo $Pic4; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Мощность:</td>
        <td><input type="text" name="Power" value="<?php if (!empty($power)) echo $power; elseif(!empty($Power)) echo $Power; else echo '' ?>"></td>
        <td>Изображение 5:</td>
        <td><input type="text" name="Pic5" value="<?php if (!empty($pic5)) echo $pic5; elseif(!empty($Pic5)) echo $Pic5; else echo '' ?>"></td>
      </tr>
      <tr>
        <td colspan="4";>
          <input type="submit" name="find_car" value="Найти автомобиль"><br>
          <input type="submit" name="save" value="Сохранить">
          <input type="submit" name="delete_car" value="Удалить автомобиль">
        </td>
      </tr>
    </table>
  </form>
</div>
</body>
<?php require "blocks/footer.php" ?>
</html>