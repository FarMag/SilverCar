<!-- Проверка нажата ли кнопка "Добавить автомобиль" -->
<?php
   session_start();
  
   if($_SESSION['user']['role'] != 1){
     header('Location: main_window.php');
   }
 
  if(isset($_POST['add_car']) && !empty($_POST['ID']) && !empty($_POST['Brand']) && !empty($_POST['Model']) && !empty($_POST['Price']) && !empty($_POST['Year']) 
                          && !empty($_POST['Mileage']) && !empty($_POST['Volume']) && !empty($_POST['Power']) && !empty($_POST['Engine_Type']) 
                          && !empty($_POST['Transmission']) && !empty($_POST['Configuration']) ){
    
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = ''; 
    $db_name = 'SilverCarDB';

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$conn) {
      die('Ошибка подключения к базе данных:' . mysqli_connect_error());
    }
    // else{
    //   echo "Есть подключение к БД <br />";
    // }

    $id = $_POST['ID'];
    $ID = $_POST['ID'];
    $Brand = $_POST['Brand'];
    $Model = $_POST['Model'];
    $Price = $_POST['Price'];
    $Year = $_POST['Year'];
    $Mileage = $_POST['Mileage'];
    $Volume = $_POST['Volume'];
    $Power = $_POST['Power'];
    $Engine_Type = $_POST['Engine_Type'];
    $Transmission = $_POST['Transmission'];
    $Configuration = $_POST['Configuration'];

    $query_carInfo = "SELECT ID FROM CarInfo WHERE ID = $ID";
    $query_carPictures = "SELECT ID FROM CarPictures WHERE CarID = $ID";

    /*if ($conn->query($query_carInfo) != ''){
      $query = "INSERT INTO CarInfo (ID, Name, Price, Year, Mileage, Volume, Power, Engine_Type, Transmission, Configuration)
              VALUES ($ID, '$Name', $Price, $Year, $Mileage, $Volume, $Power, '$Engine_Type', '$Transmission', '$Configuration')";

      if ($conn->query($query)){
        echo "Данные успешно добавлены в таблицу CarInfo <br />";
      }
      else {
        echo "Ошибка, данные не добавлены в таблицу CarInfo <br />";
      }
    }
    else {
      echo "В БД уже существует машина с таким ID (CarInfo)<br />";
    }*/


    $query = "INSERT INTO CarInfo (ID, Brand, Model, Price, Year, Mileage, Volume, Power, Engine_Type, Transmission, Configuration)
              VALUES ($ID, '$Brand', '$Model', $Price, $Year, $Mileage, $Volume, $Power, '$Engine_Type', '$Transmission', '$Configuration')";

    if ($conn->query($query)){
      echo "Данные успешно добавлены в таблицу CarInfo <br />";
    }
    else {
      echo "В БД уже существует машина с таким ID (CarInfo) <br />";
    }














    $CarID = $_POST['ID'];

    if(!empty($_POST['Pic1']))
      $Pic1 = $_POST['Pic1'];
    else
      $Pic1 = NULL;

    if(!empty($_POST['Pic2']))
      $Pic2 = $_POST['Pic2'];
    else
      $Pic2 = NULL;

    if(!empty($_POST['Pic3']))
      $Pic3 = $_POST['Pic3'];
    else
      $Pic3 = NULL;

    if(!empty($_POST['Pic4']))
      $Pic4 = $_POST['Pic4'];
    else
      $Pic4 = NULL;

    if(!empty($_POST['Pic5']))
      $Pic5 = $_POST['Pic5'];
    else
      $Pic5 = NULL;

    /*if ($conn->query($query)){
      echo "Данные успешно добавлены в таблицу CarPictures <br />";
    }
    else {
      echo "Ошибка, данные не добавлены в таблицу CarPictures <br />";
    }*/





    /*if ($conn->query($query_carPictures) == ''){
      $query = "INSERT INTO CarPictures (CarID, Pic1, Pic2, Pic3, Pic4, Pic5) VALUES ($CarID, '$Pic1', '$Pic2', '$Pic3', '$Pic4', '$Pic5')";

        if ($conn->query($query)){
          echo "Данные успешно добавлены в таблицу CarPictures <br />";
        }
        else {
          echo "Ошибка, данные не добавлены в таблицу CarPictures <br />";
        }
    }
    else {
      echo "В БД уже существует машина с таким ID (CarPictures)<br />";
    }*/

    //$query = "INSERT INTO CarPictures (CarID, Pic1, Pic2, Pic3, Pic4, Pic5) VALUES ($CarID, '$Pic1', '$Pic2', '$Pic3', '$Pic4', '$Pic5')";
    $query_carPictures = "SELECT ID FROM CarPictures WHERE CarID = $ID";
    $result_carPictures = $conn->query($query_carPictures);
    if ($result_carPictures->num_rows > 0) {
      echo "В БД уже существует машина с таким ID (CarPictures) <br />";
    } else {
      $query = "INSERT INTO CarPictures (CarID, Pic1, Pic2, Pic3, Pic4, Pic5) VALUES ($CarID, '$Pic1', '$Pic2', '$Pic3', '$Pic4', '$Pic5')";
      if ($conn->query($query)){
        echo "Данные успешно добавлены в таблицу CarPictures <br />";
      }
      else {
        echo "Ошибка, данные не добавлены в таблицу CarPictures <br />";
      }
    }

    /*if ($conn->query($query)){
      echo "Данные успешно добавлены в таблицу CarPictures <br />";
    }
    else {
      echo "В БД уже существует машина с таким ID (CarPictures) <br />";
    }*/

    $conn->close();
  } 
  else if (isset($_POST['add_car'])){
    echo "Ошибка, вы ввели не все данные";
  }
?>







<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/header_style.css">
    <link rel="stylesheet" type="text/css" href="css/footer_style.css">
    <link rel="stylesheet" type="text/css" href="css/admin_add_car_style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <title>Панель администратора - добавление автомобиля</title>
</head>
<?php require "blocks/header.php" ?>
<body>
  <!-- <h1>Добавление автомобиля</h1> -->

  <div class="container">
  <form method="POST" action="">
    <!-- <input type="hidden" name="ID" value="<php if ($ID != null) echo $id; ?>"> -->
    <table class="table">
      <tr><th colspan="4">Добавление автомобиля</th></tr>
      <tr>
        <td>ID:</td>
        <td><input type="text" name="ID" id="ID" value="<?php if (!empty($_POST['ID'])) echo $_POST['ID']; else echo '' ?>"></td>
        <td width=30%;>Тип двигателя:</td>
        <td><input type="text" name="Engine_Type" value="<?php if (!empty($_POST['Engine_Type'])) echo $_POST['Engine_Type']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Марка:</td>
        <td><input type="text" name="Brand" value="<?php if (!empty($_POST['Brand'])) echo $_POST['Brand']; else echo '' ?>"></td>
        <td>Коробка передач:</td>
        <td><input type="text" name="Transmission" value="<?php if (!empty($_POST['Transmission'])) echo $_POST['Transmission']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Модель:</td>
        <td><input type="text" name="Model" value="<?php if (!empty($_POST['Model'])) echo $_POST['Model']; else echo '' ?>"></td>
        <td>Комплектация:</td>
        <td><input type="text" name="Configuration" value="<?php if (!empty($_POST['Configuration'])) echo $_POST['Configuration']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Цена:</td>
        <td><input type="text" name="Price" value="<?php if (!empty($_POST['Price'])) echo $_POST['Price']; else echo '' ?>"></td>
        <td>Изображение 1:</td>
        <td><input type="text" name="Pic1" value="<?php if (!empty($_POST['Pic1'])) echo $_POST['Pic1']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Год:</td>
        <td><input type="text" name="Year" value="<?php if (!empty($_POST['Year'])) echo $_POST['Year']; else echo '' ?>"></td>
        <td>Изображение 2:</td>
        <td><input type="text" name="Pic2" value="<?php if (!empty($_POST['Pic2'])) echo $_POST['Pic2']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Пробег:</td>
        <td><input type="text" name="Mileage" value="<?php if (!empty($_POST['Mileage'])) echo $_POST['Mileage']; else echo '' ?>"></td>
        <td>Изображение 3:</td>
        <td><input type="text" name="Pic3" value="<?php if (!empty($_POST['Pic3'])) echo $_POST['Pic3']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Объем двигателя:</td>
        <td><input type="text" name="Volume" value="<?php if (!empty($_POST['Volume'])) echo $_POST['Volume']; else echo '' ?>"></td>
        <td>Изображение 4:</td>
        <td><input type="text" name="Pic4" value="<?php if (!empty($_POST['Pic4'])) echo $_POST['Pic4']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td>Мощность:</td>
        <td><input type="text" name="Power" value="<?php if (!empty($_POST['Power'])) echo $_POST['Power']; else echo '' ?>"></td>
        <td>Изображение 5:</td>
        <td><input type="text" name="Pic5" value="<?php if (!empty($_POST['Pic5'])) echo $_POST['Pic5']; else echo '' ?>"></td>
      </tr>
      <tr>
        <td colspan="4">
          <input type="submit" name="add_car" value="Добавить">
        </td>
      </tr>
    </table>
  </form>
  </div>

</body>
<?php require "blocks/footer.php" ?>
</html>