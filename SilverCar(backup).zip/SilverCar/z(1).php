

<?php
session_start();
if(isset($_POST["sort_select"])){
    setcookie("sort_select", $_POST["sort_select"]);
    $sort = $_COOKIE["sort_select"];
}

$host = 'localhost';
$username = 'root'; 
$password = '';  
$dbname = 'SilverCarDB';

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die('Ошибка соединения с MySQL: ' . mysqli_connect_error());
}
$brand_arr = ["Porsche", "Mercedes-Benz", "BMW", "Volkswagen", "Rolls-Royce", "Lexus", "Toyota", "Zeekr", "ВАЗ (LADA)", "Dodge", "Mitsubishi", "LiXiang", "Genesis", "Jeep", "Land Rover"];

// $brandQuery = "SELECT DISTINCT Brand FROM CarInfo";
// $brandResult = mysqli_query($conn, $brandQuery);

?>

<!DOCTYPE html>
<html>
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link href="css\style.css" type="text/css" rel="stylesheet"> -->
    <link rel="stylesheet" type="text/css" href="css/main_window_style.css">
    <link rel="stylesheet" type="text/css" href="css/header_style.css">
    <link rel="stylesheet" type="text/css" href="css/footer_style.css">
    <!-- <car onclick="location.href='car_window.php';">Redirect to another site</div> -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <style>
        
    </style>

    <title>SilverCar - Салон поддержанных автомобилей</title>
</head>

<?php require "blocks/header.php" ?>

<body>
    
 <!-- <form method="POST">
 <div class="selectWrapper">
  <select name="sort_select" class="selectBox" onchange="this.form.submit()">
  <option name="by_id" value="ORDER BY ID" <php if ($sort === 'ORDER BY ID') echo 'selected'; ?> >Сначала старые предложения</option>
  <option name="by_id_desc" value="ORDER BY ID DESC" <php if ($sort === 'ORDER BY ID DESC') echo 'selected'; ?> >Сначала новые предложения</option>
  <option name="by_price" value="ORDER BY Price" <php if ($sort === 'ORDER BY Price') echo 'selected'; ?> >Сначала дешевле</option>
  <option name="by_price_desc" value="ORDER BY Price DESC" <php if ($sort === 'ORDER BY Price DESC') echo 'selected'; ?> >Сначала дороже</option>
</select>
<noscript><input type="submit" value="Submit"></noscript>
</div>

<button class="btn" type="button" id="open-modal-btn">Фильтры</button>

</form> -->

<form method="POST">
 <div class="selectWrapper">
  <select name="sort_select" class="selectBox" onchange="this.form.submit()">
  <option name="by_id" value="ORDER BY ID" <?php if ($sort === 'ORDER BY ID') echo 'selected'; ?> >Сначала старые предложения</option>
  <option name="by_id_desc" value="ORDER BY ID DESC" <?php if ($sort === 'ORDER BY ID DESC') echo 'selected'; ?> >Сначала новые предложения</option>
  <option name="by_price" value="ORDER BY Price" <?php if ($sort === 'ORDER BY Price') echo 'selected'; ?> >Сначала дешевле</option>
  <option name="by_price_desc" value="ORDER BY Price DESC" <?php if ($sort === 'ORDER BY Price DESC') echo 'selected'; ?> >Сначала дороже</option>
</select>
<noscript><input type="submit" value="Submit"></noscript>
</div>

<button class="btn" type="button" id="open-modal-btn">Фильтры</button>

</form>

<div id="modal" class="modal">
                <div class="modal-content">
                <span class="close">&times;</span><br>
                <h4>Выберите марку</h4>
                <form>

                <?php 
                for($i=1; $i<count($brand_arr)+1; $i++){
                    echo "<input type='checkbox' name='cb_brand[]' value=".$brand_arr[$i-1]." id='checkbox$i'>
                    <label for='checkbox$i'>".$brand_arr[$i-1]."</label>
                    <br>";
                }
                
                ?>

                    <br><button type="submit" class="filter_btn">Применить</button>
                </form>
                </div>
            </div>

            

<?php
    $query = "SELECT * FROM CarInfo $sort";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['ID'];
        $brand = $row['Brand'];
        $model = $row['Model'];
        $price = $row['Price'];
        $query_pic = "SELECT Pic1 FROM CarPictures cp JOIN CarInfo ci ON ci.ID = cp.CarID WHERE ci.ID = $id";
        echo "<div class='container'>
                <a href='car_window.php?id=$id' style='text-decoration: none;'> <!-- Добавляем ссылку с параметром id -->
                <div class='car' id='$id'>
                    <table>
                        <tr>
                            <td width='700px' height='200px'>";
        $result_pic = $conn->query($query_pic);
        if ($result_pic->num_rows > 0) {
            $row_pic = $result_pic->fetch_assoc();
            $pic = !empty($row_pic['Pic1']) ? $row_pic['Pic1'] : 'images\дефолт\(1).jpg';
            echo "<img src='$pic' alt='$brand $model' />";
        } 
        else {
            echo "<img src='images\дефолт\(1).jpg' alt='$brand $model' />";
        }

        echo 
                        "</td>
                        </tr>
                        <tr><td><h2>$brand $model</h2></td></tr>
                        <tr><td><h3>" . number_format($price, 0, '.', ' ') . " ₽</h3></td></tr>  
                    </table>
                    <br>
                </div>
            </a>
        </div>";
    }
            
    mysqli_close($conn);
?>

    <?php require "blocks/footer.php" ?>
</body>
</html>

<?php
//Ваш PHP код для обработки данных и отправки заказа
?>



<script>
    
    window.onload = function() {
  var modal = document.getElementById("modal");
  var openModalBtn = document.getElementById("open-modal-btn");
  var closeModalBtn = document.getElementsByClassName("close")[0];

  openModalBtn.onclick = function() {
    modal.style.display = "block";
  }

  closeModalBtn.onclick = function() {
    modal.style.display = "none";
  }

  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
};
</script>