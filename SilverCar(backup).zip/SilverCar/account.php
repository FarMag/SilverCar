<?php session_start();

    if (empty($_SESSION['user'])){
        header('Location: login.php');
    }

    if (isset($_POST['logout'])){
        session_destroy();
        header('Location: login.php');
    }
    
?>

<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.w3.org/1999/xhtml">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link href="css\style.css" type="text/css" rel="stylesheet"> -->
    <!--<link rel="stylesheet" type="text/css" href="css/main_window_style.css">-->
    <link rel="stylesheet" type="text/css" href="css/header_style.css">
    <link rel="stylesheet" type="text/css" href="css/footer_style.css">
    <link rel="stylesheet" type="text/css" href="css/account_style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- <style>
    <php include "css/account.css" ?>
    <php include "css/header_style.css" ?>
    <php include "css/footer_style.css" ?>
    </style> -->
</head>

<?php require "blocks/header.php" ?>

<div class="container">
<form method="POST" action="">
    <body class="body">
        
    <table class="table">
    <tr>
        <th colspan="2">Личные данные</th>
    </tr>
    <tr>
        <td>Имя</td>
        <td><?= $_SESSION['user']['name']; ?></td>
    </tr>
    <tr>
        <td>Почта</td>
        <td><?= $_SESSION['user']['email']; ?></td>
    </tr>
</table>
 
        <?php if($_SESSION['user']['role'] == 1){
      echo '<br><a href="/admin_panel.php" class="admin_panel_button">Изменить/удалить записи</a><br>';
      echo '<a href="/admin_add_car.php" class="admin_add_car_button">Создать запись</a><br>';
      echo '<a href="/request.php"class="request_button">Запросы на обратную связь</a><br>';
      echo '<input type="submit" name="logout" value="Выйти" class="logout_button">';
    }else{
        echo "<input type='submit' name='logout' value='Выйти' class='logout_button_1'>";
    }?>
        <!-- <a href="/login.php" type="submit" name="logout" class="logout_button">Выйти</a> -->
    </body>
</form>
</div>

<?php require "blocks/footer.php" ?>

</html>